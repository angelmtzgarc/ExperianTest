var Tcc = window.Tcc || {};
Tcc.SurveyEngine = window.Tcc.SurveyEngine || {};
Tcc.SurveyEngine.GenericSurvey = window.Tcc.SurveyEngine.GenericSurvey || {};
Tcc.SurveyEngine.SpecificSurvey = window.Tcc.SurveyEngine.SpecificSurvey || {};

Tcc.SurveyEngine.GenericSurvey.Start = function (checkForBackButtonPress, hookUpBackButtonCatch) {
    checkForBackButtonPress();
    hookUpBackButtonCatch();
}