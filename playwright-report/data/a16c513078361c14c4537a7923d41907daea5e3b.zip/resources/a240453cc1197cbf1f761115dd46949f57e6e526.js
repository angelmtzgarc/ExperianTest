var Tcc = window.Tcc || {};
Tcc.SurveyEngine = window.Tcc.SurveyEngine || {};
Tcc.SurveyEngine.GenericSurvey = window.Tcc.SurveyEngine.GenericSurvey || {};
Tcc.SurveyEngine.SpecificSurvey = window.Tcc.SurveyEngine.SpecificSurvey || {};

Tcc.SurveyEngine.GenericSurvey.Main = (function () {

    $(document).ready(function () {
        window.onunload = function () { };
        if (!!Tcc.SurveyEngine.GenericSurvey.Start)
            Tcc.SurveyEngine.GenericSurvey.Start(checkForBackButtonPress, hookUpBackButtonCatch);
        else if (!!Tcc.SurveyEngine.GenericSurvey.End)
            Tcc.SurveyEngine.GenericSurvey.End(registerGenericEnd);

        styleButton();
        prePopulateFields();
        hideSpouseTribeQuestions();

        $("#SurveyControl_CloseIframe").on('click', function () {
            sessionStorage.setItem('closeiFrame', 'true');
            window.parent.postMessage("survey-completed", "*");
        });
        $("form").on('submit', function (event) {
            $(this).on('submit', function () {
                return false;
            });
            return true;
        });

        if ((hasQuestions() || hasNoNeedToSurveyMessage()) && (sessionStorage.getItem('closeiFrame') == 'false' || sessionStorage.getItem('closeiFrame') == null)) {
            window.parent.postMessage("questions-loaded", "*");
        } else {
            window.parent.postMessage("survey-completed", "*");
            sessionStorage.setItem('closeiFrame', 'false');
        }

        getMilitaryStatusSelector().on('change', function (e) {
            if ($(this).find('option:selected').attr("data-answer-id-text") == 'CurrentlyEnlisted') {
                hideDischargeDate();
            } else {
                showDischargeDate();
            }
        });

        //This is a hack, would be cleaner with dropdown but still a hack
        getNativeAmericanTribeMemberSelector().on('change', function () {
            var text = $("div[data-question-id-text='NativeAmericanTribeMember']").find('.active')[0].innerText;
            if (caseInsensitiveEquals(text, 'My Spouse') ||
                caseInsensitiveEquals(text, 'Mi cónyuge') ||
                caseInsensitiveEquals(text, '我的配偶') ||
                caseInsensitiveEquals(text, 'Vợ/chồng tôi') ||
                caseInsensitiveEquals(text, '내 배우자') ||
                caseInsensitiveEquals(text, 'Asawa Ko') ||
                caseInsensitiveEquals(text, 'Mon époux/épouse')) {
                hideSelfTribeQuestions();
                showSpouseTribeQuestions();
            } else {
                hideSpouseTribeQuestions();
                showSelfTribeQuestions();
            }
        });

        updateLanguage();
        resizeCustomLogo();
        createDateInputs();

        if (!!Tcc.SurveyEngine.SpecificSurvey.init) {
            Tcc.SurveyEngine.SpecificSurvey.init();
        }

        getEightyEightFifty();
        hookUpComboBoxes();
        hookUpConfirmationCopy();
    });

    function styleButton() {
        var optOutbutton = $(".opt-out-button");
        var continuebutton = optOutbutton.siblings("input[type=submit]");

        continuebutton.addClass("continue-button");

        switch (continuebutton.val()) {
            case "Next":
                continuebutton.val("CONTINUE");
                optOutbutton.val("Opt Out");
                break;
            case "Siguiente":
                continuebutton.val("CONTINUAR");
                optOutbutton.val("Declinar");
                break;
            case "下一步":
                continuebutton.val("继续");
                optOutbutton.val("选择退出");
                break;
            case "Tiếp theo":
                continuebutton.val("Tiếp tục");
                optOutbutton.val("Lựa chọn không nhận");
                break;
            case "다음":
                continuebutton.val("계속");
                optOutbutton.val("기피");
                break;
            case "Susunod":
                continuebutton.val("Magpatuloy");
                optOutbutton.val("Mag-opt Out");
                break;
            case "Suivant":
                continuebutton.val("Continuer");
                optOutbutton.val("Se retirer");
                break;


        }
    }

    function getNativeAmericanTribeMemberSelector() {
        return $("div[data-question-id-text='NativeAmericanTribeMember'] input");
    }

    function hideSelfTribeQuestions() {
        $("div[data-question-id-text='NativeAmericanTribe']").first().slideUp();
        $("div[data-question-id-text='NativeAmericanTribeCity']").first().slideUp();
        $("div[data-question-id-text='NativeAmericanTribeState']").first().slideUp();
        $("div[data-question-id-text='NativeAmericanTribeMembershipNumber']").first().slideUp();
        $("div[data-question-id-text='NativeAmericanMaidenName']").first().slideUp();
    }

    function showSelfTribeQuestions() {
        $("div[data-question-id-text='NativeAmericanTribe']").first().slideDown();
        $("div[data-question-id-text='NativeAmericanTribeCity']").first().slideDown();
        $("div[data-question-id-text='NativeAmericanTribeState']").first().slideDown();
        $("div[data-question-id-text='NativeAmericanTribeMembershipNumber']").first().slideDown();
        $("div[data-question-id-text='NativeAmericanMaidenName']").first().slideDown();
    }

    function hideSpouseTribeQuestions() {
        $("div[data-question-id-text='NativeAmericanSpouse']").first().slideUp();
    }

    function showSpouseTribeQuestions() {
        $("div[data-question-id-text='NativeAmericanSpouse']").first().slideDown();
    }

    function getMilitaryStatusSelector() {
        return $("div[data-question-id-text='USArmedForcesStatus']")
            .find("select");
    }

    function hideDischargeDate() {
        getDischargeQuestion().slideUp();
    }

    function showDischargeDate() {
        getDischargeQuestion().slideDown();
    }

    function getDischargeQuestion() {
        return $("div[data-question-id-text='USArmedForcesDischargeDate']").first();
    }

    function hasQuestions() {
        return $('div[id^=SurveyControl_Question]').length != 0;
    }

    function hasNoNeedToSurveyMessage() {
        return $('#SurveyControl_NoNeedToSurveyRow').length != 0;
    }

    function prePopulateFields() {
        var firstName = $('#hddVoterFirstName').val();
        var middleName = $('#hddVoterMiddleName').val();
        var lastName = $('#hddVoterLastName').val();
        var city = $('#hddVoterCity').val();
        var usState = $('#hddVoterAddressState').val();
        var location = $('#hddVoterLocation').val();

        if (typeof firstName !== 'undefined' && typeof lastName !== 'undefined')
            var fullName = firstName + (firstName.length === 0 || lastName.length === 0 ? lastName : ' ' + lastName);

        var locationDropDown = $("div[data-question-id-text=VoterLocation] select");

        if (typeof firstName !== 'undefined' && firstName.length != 0)
            $("div[data-question-id-text=VoterFirstName] input").val(firstName);

        if (typeof middleName !== 'undefined' && middleName.length != 0)
            $("div[data-question-id-text=VoterMiddleName] input").val(middleName);

        if (typeof lastName !== 'undefined' && lastName.length != 0)
            $("div[data-question-id-text=VoterLastName] input").val(lastName);

        if (typeof fullName !== 'undefined' && fullName.length != 0)
            $("div[data-question-id-text=NameConfirmation] input").val(fullName);

        if (typeof city !== 'undefined' && city.length != 0)
            $("div[data-question-id-text=VoterCity], div[data-question-id-text=SnapCity], div[data-question-id-text=TanfCity], div[data-question-id-text=ConvictedCity]")
                .find('input').val(city);

        if (typeof usState !== 'undefined' && usState.length != 0)
            $("div[data-question-id-text=SnapState], div[data-question-id-text=TanfState], div[data-question-id-text=ConvictedState], div[data-question-id-text=LtuState], div[data-question-id-text=NativeAmericanTribeState]")
                .find('select').val(usState);

        if ($('div[data-question-id-text=VoterLocation] select option[value="' + location + '"]').length != 0)
            $("div[data-question-id-text=VoterLocation] select").val(location);
    }

    function caseInsensitiveEquals(a, b) {
        return typeof a === 'string' && typeof b === 'string'
            ? a.localeCompare(b, undefined, { sensitivity: 'accent' }) === 0
            : a === b;
    }

    function updateLanguage() {
        var $languages = $('#language-selection-section a');
        if ($languages.length == 0) {
            $('#tcc-navbar').each(function () {
                this.style.setProperty('display', 'none', 'important');
            });
            $('.navbar-toggler').hide();
        }
        else {
            $('#language-selections').empty();
            $('#language-selections').append($languages);
            $('a.language-link').wrap('<li></li>');
            $('a.language-link').on('click', onLanguageClick);
        }
    }

    function resizeCustomLogo() {
        var $customLogo = $('.tcc-default-custom-logo');
        if ($customLogo.length > 0) {
            var imgHeight = $customLogo[0].clientHeight;
            updateLogoAndHeaderPlacement(imgHeight);

            $(window).resize(function () {
                if ($customLogo[0].clientHeight != imgHeight) {
                    imgHeight = $customLogo[0].clientHeight;
                    updateLogoAndHeaderPlacement(imgHeight);
                }
            });
        }
    }

    function updateLogoAndHeaderPlacement(imgHeight) {
        $('#survey-box').css({ 'padding-top': (imgHeight + 50).toString() + 'px' });

        var navbarHeight = $('.survey-navbar')[0].clientHeight;
        $('.navbar-collapser').css({ 'top': navbarHeight.toString() + 'px' });
    }

    function createDateInputs() {
        var dateInputs = $(".date-question").closest(".form-group").find("input");

        $.each(dateInputs, function (index, value) {
            if (!$(value).hasClass("hasDatepicker")) {
                $(value).datepicker({
                    changeMonth: true,
                    changeYear: true,
                    yearRange: "-100:+0"
                });
            }
        });
    }

    function onLanguageClick(e) {
        e.preventDefault();
        var language = e.target.id;
        __doPostBack(language, '');
    }

    function hookUpBackButtonCatch() {
        var bbCatch = $('div[id$=_bb-catch]')[0];
        if (!!bbCatch) {
            window.sessionStorage.setItem("redirectUrl", bbCatch.attributes['data-url'].value);
        }
    }

    function checkForBackButtonPress() {
        var url = window.sessionStorage.getItem("redirectUrl");

        if (!!url && url !== '') {
            window.sessionStorage.setItem("redirectUrl", '');
            window.location.replace(url);
            return;
        }
    }

    function registerGenericEnd() {
        window.sessionStorage.setItem("redirectUrl", window.location.href);

        var i;
        for (i = 0; i < 100; i++) {
            history.pushState({}, '');
        }
    }

    function getEightyEightFifty() {
        var receiptId = document.getElementById('hddReceiptIdentifier');
        var atsUrl = document.getElementById('hddAtsUrl');
        if (!(typeof (receiptId.value) === 'undefined' || receiptId.value == null || receiptId.value === '')
            && !(typeof (atsUrl.value) === 'undefined' || atsUrl.value == null || atsUrl.value === '')) {
            showForms('<div class="embed-loading item"><img /></div>');

            var oReq = new XMLHttpRequest();
            oReq.addEventListener('load', function (e) {
                showForms(this.responseText);
                $('.embed-loading').css('background-image', 'none');
            });
            oReq.addEventListener('error', function (e) { console.log(this.responseText); });
            oReq.addEventListener('abort', function (e) { console.log(this.responseText); });
            oReq.open('GET', atsUrl.value + "/EightyEightFiftyService.svc/Generate?rid=" + receiptId.value);
            oReq.setRequestHeader('Access-Control-Allow-Origin', window.location.protocol + '//' + window.location.host);
            oReq.send();
        }
    }

    function showForms(htmlString) {
        var forms = document.getElementById('forms');
        if (!!forms)
            forms.innerHTML = htmlString + '<br/>';
    }

    function hookUpComboBoxes() {
        var $comboBoxes = $('.combobox-tcc');
        if ($comboBoxes.length > 0) {
            document.addEventListener('keyup', filterComboBox);
            $comboBoxes.each(function () {
                var $inputEl = $(this);
                var $outerContainer = $inputEl.closest('.dropdown-tcc');
                var $button = $outerContainer.find('.btn-toggler');
                var $silentTrigger = $outerContainer.find('div[id^="Combobox_"]');
                $button.on('click touchend', function (e) {
                    e.stopPropagation();
                    e.preventDefault();
                    $silentTrigger.dropdown('toggle');
                });

                var $options = $outerContainer.find('.dropdown-menu > li');
                $options.each(function () {
                    $(this)[0].addEventListener('click', function (e) {
                        $inputEl[0].value = $(this).text();
                        filterComboBox({ target: $inputEl[0] });
                    });
                });
            });
        }
    }

    function filterComboBox(e) {
        var $input = $(e.target);
        var lowerCaseVal = (e.target.value || '').toLowerCase();

        var $outerContainer = $input.closest('.dropdown-tcc');

        if (e.target.value === '') {
            if ($outerContainer.hasClass('open'))
                $outerContainer.removeClass('open');
        }
        else {
            if (!$outerContainer.hasClass('open'))
                $outerContainer.addClass('open');
        }

        var $customOptions = $('.dropdown-menu-tcc-custom');
        $customOptions.remove();

        var $dropdownOptions = $outerContainer.find('.dropdown-menu-tcc > li');
        var matchFound = !!0;
        $dropdownOptions.each(function () {
            if (e.target.value === '' || $(this).text().toLowerCase().search(lowerCaseVal) > -1) {
                $(this).show();
                matchFound = !!1;
            }
            else
                $(this).hide();
        });

        if (!(!!matchFound)) {
            var $clone = $dropdownOptions.eq(0).clone().addClass('dropdown-menu-tcc-custom');
            $clone.find('a').text(e.target.value);
            $clone.show();
            $outerContainer.find('.dropdown-menu-tcc').append($clone);
        }
    }

    function hookUpConfirmationCopy() {
        var el = document.getElementById('SurveyControl_ButtonCopyConfirmationNumber');
        if (!(typeof (el) === 'undefined' || el == null || el.length == 0)) {
            el.addEventListener('click', function (e) {
                var copyText = document.getElementById("hddConfirmationNumber");

                copyText.type = 'text';

                copyText.select();
                copyText.setSelectionRange(0, 100); /*For mobile devices*/

                document.execCommand("copy");

                //This is a hack for dynamic language
                switch (el.value) {
                    case "Copy Confirmation Number":
                        el.value = "Copied!";
                        break;
                    case "Copiar número de confirmación":
                        el.value = "¡Copiado!";
                        break;
                    case "复制确认号码":
                        el.value = "已复制！";
                        break;
                    case "Sao chép lại Mã Số Xác Nhận":
                        el.value = "Đã sao chép!";
                        break;
                    case "확인 번호 복사":
                        el.value = "복사됨!";
                        break;
                    case "Copier numéro de confirmation":
                        el.value = "Copié!";
                        break;
                    case "Kopyahin ang Confirmation Number":
                        el.value = "Nakopya!";
                        break;
                }
                copyText.type = 'hidden';
            });
        }
    }
})($);

Tcc.SurveyEngine.GenericSurvey.IsChrome = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor);